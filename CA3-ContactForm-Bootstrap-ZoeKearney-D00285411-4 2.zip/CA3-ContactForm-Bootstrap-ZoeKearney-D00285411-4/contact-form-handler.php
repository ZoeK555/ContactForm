<?php



$errors = '';
$myemail = 'D00285411@student.dkit.ie';// <-----Put your DkIT email address here.
var_dump($_POST);
if (empty($_POST['name']) ||
   empty($_POST['email']) ||
   empty($_POST['service']) || 
   empty($_POST['contactNumber']) ||
   empty($_POST['message']))
{
    $errors .= "\n Error: all fields are required";
}


// Important: Create email headers to avoid spam folder
$headers = 'From: '.$myemail."\r\n".
    'Reply-To: '.$myemail."\r\n" .
    'X-Mailer: PHP/' . phpversion();


  $name = $_POST['name'];
  $emailAddress = $_POST['email'];
  $service = $_POST['service'];
  $contactNumber = $_POST['contactNumber'];
  $message = $_POST['message'];

if (!preg_match(
"/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i",
$emailAddress))
{
    $errors .= "\n Error: Invalid email address";
}

if (empty($errors))
{
        $to = $myemail;
        $email_subject = "Contact form submission: $name";
        $email_body =
        "You have received a new message. ".
        " Here are the details:\n Name: $name \n Email: $emailAddress \n Contact Number: $contactNumber \n Service: $service \n Message \n $message";

        $success = mail($to,$email_subject,$email_body,$headers);
        //redirect to the 'thank you' page
        header('Location: 3ContactUs.html?success=' . $success);
        
}
?>
<!DOCTYPE HTML>
<html>
<head>
        <title>Contact form handler</title>
</head>

<body>
<!-- This page is displayed only if there is some error -->
<?php
echo nl2br(htmlspecialchars($errors, ENT_QUOTES, 'UTF-8'));
?>
</body>
</html>